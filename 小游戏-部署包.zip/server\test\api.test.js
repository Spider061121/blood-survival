'use strict';

const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { openDb, GameDb } = require('../db');
const { createApp } = require('../app');

const PASSWORD = 'pass123456';

async function makeServer(opts = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bs-test-'));
  const db = new GameDb(openDb(path.join(dir, 'test.db')));
  const app = createApp({
    db,
    sessionSecret: 'test-secret',
    rateMax: 1000,
    authRateMax: 1000,
    ...opts,
  });
  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const base = `http://127.0.0.1:${server.address().port}`;
  return {
    base,
    db,
    async close() {
      await new Promise((r) => server.close(r));
      db.close();
      fs.rmSync(dir, { recursive: true, force: true });
    },
  };
}

function cookieOf(res) {
  const raw = res.headers.get('set-cookie') || '';
  return raw.split(';')[0];
}

function headers(cookie, extra = {}) {
  return {
    'Content-Type': 'application/json',
    ...(cookie ? { Cookie: cookie } : {}),
    ...extra,
  };
}

async function apiJson(res) {
  return res.json();
}

async function register(base, username, password = PASSWORD) {
  const res = await fetch(`${base}/api/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  return { status: res.status, body: await apiJson(res), cookie: cookieOf(res) };
}

async function login(base, username, password = PASSWORD) {
  const res = await fetch(`${base}/api/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  return { status: res.status, body: await apiJson(res), cookie: cookieOf(res) };
}

async function me(base, cookie) {
  const res = await fetch(`${base}/api/me`, { headers: headers(cookie) });
  return { status: res.status, body: await apiJson(res) };
}

async function submit(base, cookie, payload) {
  const res = await fetch(`${base}/api/score`, {
    method: 'POST',
    headers: headers(cookie),
    body: JSON.stringify(payload),
  });
  return { status: res.status, body: await apiJson(res) };
}

async function leaderboard(base, limit) {
  const q = limit === undefined ? '' : `?limit=${limit}`;
  const res = await fetch(`${base}/api/leaderboard${q}`);
  return res.json();
}

const good = { survivalSeconds: 42.5, kills: 81, endHp: 0 };

test('健康检查与未知接口', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  const health = await fetch(`${env.base}/api/health`);
  assert.equal(health.status, 200);
  assert.equal((await health.json()).ok, true);

  const notFound = await fetch(`${env.base}/api/nope`);
  assert.equal(notFound.status, 404);
  assert.equal((await notFound.json()).ok, false);
});

test('注册后自动登录，/api/me 返回用户信息', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  const r = await register(env.base, '小明同学');
  assert.equal(r.status, 200);
  assert.equal(r.body.ok, true);
  assert.ok(r.cookie.startsWith('sid='), '注册后应下发会话 Cookie');

  const m = await me(env.base, r.cookie);
  assert.equal(m.status, 200);
  assert.equal(m.body.data.username, '小明同学');
  assert.equal(m.body.data.best, null);
  assert.equal(m.body.data.rank, null);

  const anon = await me(env.base, '');
  assert.equal(anon.status, 401);
});

test('用户名占用返回 409', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  await register(env.base, '老王头');
  const dup = await register(env.base, '老王头');
  assert.equal(dup.status, 409);
});

test('注册参数校验', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  const cases = [
    { username: 'ab', password: PASSWORD }, // 太短
    { username: '', password: PASSWORD },
    { username: 'bad name!', password: PASSWORD }, // 非法字符
    { username: '合法名字', password: '12345' }, // 密码太短
    { username: '合法名字2', password: '' },
  ];
  for (const c of cases) {
    const res = await fetch(`${env.base}/api/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(c),
    });
    assert.equal(res.status, 400, `应拒绝: ${JSON.stringify(c)}`);
    assert.equal((await res.json()).ok, false);
  }
});

test('登录：密码错误 401，正确 200', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  await register(env.base, '登录测试');
  const bad = await login(env.base, '登录测试', 'wrong-password');
  assert.equal(bad.status, 401);

  const ok = await login(env.base, '登录测试');
  assert.equal(ok.status, 200);
  assert.ok(ok.cookie.startsWith('sid='));

  const m = await me(env.base, ok.cookie);
  assert.equal(m.status, 200);
  assert.equal(m.body.data.username, '登录测试');
});

test('未登录不能提交成绩', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  const r = await submit(env.base, '', good);
  assert.equal(r.status, 401);
});

test('提交成绩绑定账号，返回个人最好成绩与排名', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  const { cookie } = await register(env.base, '成绩测试');
  const r = await submit(env.base, cookie, good);
  assert.equal(r.status, 200);
  assert.equal(r.body.data.accepted, true);
  assert.equal(r.body.data.rank, 1);
  assert.equal(r.body.data.best.survivalSeconds, 42.5);
  assert.equal(r.body.data.best.kills, 81);

  const m = await me(env.base, cookie);
  assert.equal(m.body.data.best.survivalSeconds, 42.5);
  assert.equal(m.body.data.rank, 1);

  const lb = await leaderboard(env.base);
  assert.equal(lb.data.total, 1);
  assert.equal(lb.data.items[0].username, '成绩测试');
  assert.equal(lb.data.items[0].survivalSeconds, 42.5);
});

test('排行榜按每人最好成绩排名（一人一条）', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  const a = await register(env.base, '甲玩家');
  const b = await register(env.base, '乙玩家');
  const c = await register(env.base, '丙玩家');

  await submit(env.base, a.cookie, { ...good, survivalSeconds: 20, kills: 5 });
  await submit(env.base, b.cookie, { ...good, survivalSeconds: 30, kills: 1 });
  await submit(env.base, c.cookie, { ...good, survivalSeconds: 10, kills: 99 });
  // 甲再来一局，刷新个人最好成绩
  const a2 = await submit(env.base, a.cookie, { ...good, survivalSeconds: 40, kills: 7 });
  assert.equal(a2.body.data.best.survivalSeconds, 40);

  const lb = await leaderboard(env.base);
  assert.equal(lb.data.total, 3);
  assert.equal(lb.data.items.length, 3);
  assert.deepEqual(
    lb.data.items.map((x) => x.username),
    ['甲玩家', '乙玩家', '丙玩家']
  );
  assert.equal(lb.data.items[0].survivalSeconds, 40);

  const m = await me(env.base, a.cookie);
  assert.equal(m.body.data.rank, 1);
});

test('成绩参数校验', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  const { cookie } = await register(env.base, '校验测试');
  const cases = [
    { ...good, survivalSeconds: -1 },
    { ...good, survivalSeconds: 86401 },
    { ...good, survivalSeconds: 'abc' },
    { ...good, kills: 1.5 },
    { ...good, kills: -3 },
    { ...good, endHp: 101 },
    { ...good, endHp: -1 },
  ];
  for (const p of cases) {
    const r = await submit(env.base, cookie, p);
    assert.equal(r.status, 400, `应拒绝: ${JSON.stringify(p)}`);
  }
});

test('成绩提交限频返回 429', async (t) => {
  const env = await makeServer({ rateMax: 2 });
  t.after(() => env.close());

  const { cookie } = await register(env.base, '限频测试');
  const r1 = await submit(env.base, cookie, good);
  const r2 = await submit(env.base, cookie, good);
  const r3 = await submit(env.base, cookie, good);
  assert.equal(r1.status, 200);
  assert.equal(r2.status, 200);
  assert.equal(r3.status, 429);
});

test('登录/注册限频返回 429', async (t) => {
  const env = await makeServer({ authRateMax: 2 });
  t.after(() => env.close());

  const a = await register(env.base, '用户甲');
  const b = await register(env.base, '用户乙');
  const c = await register(env.base, '用户丙');
  assert.equal(a.status, 200);
  assert.equal(b.status, 200);
  assert.equal(c.status, 429);
});

test('退出登录清除会话 Cookie', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  const { cookie } = await register(env.base, '退出测试');
  const res = await fetch(`${env.base}/api/logout`, {
    method: 'POST',
    headers: { Cookie: cookie },
  });
  assert.equal(res.status, 200);
  const setCookie = res.headers.get('set-cookie') || '';
  assert.ok(setCookie.includes('sid=;'), '应清除 sid Cookie');
});

test('limit 参数上限 100', async (t) => {
  const env = await makeServer();
  t.after(() => env.close());

  for (let i = 0; i < 5; i++) {
    const r = await register(env.base, `玩家${i}`);
    await submit(env.base, r.cookie, { ...good, survivalSeconds: i + 1 });
  }
  const lb = await leaderboard(env.base, 999);
  assert.ok(lb.data.items.length <= 100);
  assert.equal(lb.data.items.length, 5);
  assert.equal(lb.data.total, 5);

  const small = await leaderboard(env.base, 2);
  assert.equal(small.data.items.length, 2);
});

test('v1 旧数据库自动迁移为备份表', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bs-legacy-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));

  const file = path.join(dir, 'game.db');
  const legacy = new DatabaseSync(file);
  legacy.exec(`
    CREATE TABLE scores (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nickname TEXT NOT NULL,
      survival_seconds REAL NOT NULL,
      kills INTEGER NOT NULL,
      end_hp INTEGER NOT NULL,
      ip_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);
  legacy.exec(
    "INSERT INTO scores (nickname, survival_seconds, kills, end_hp, ip_hash, created_at) VALUES ('老玩家', 99, 9, 0, 'abc', '2026-01-01T00:00:00.000Z')"
  );
  legacy.close();

  const raw = openDb(file);
  const gdb = new GameDb(raw);
  const tables = raw
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table'")
    .all()
    .map((r) => r.name);
  assert.ok(tables.includes('scores_v1_backup'), '旧表应改名为备份表');
  assert.ok(tables.includes('users'));
  const cols = raw.prepare('PRAGMA table_info(scores)').all().map((c) => c.name);
  assert.ok(cols.includes('user_id'), '新 scores 表应有 user_id');
  const legacyCount = raw.prepare('SELECT COUNT(*) AS c FROM scores_v1_backup').get().c;
  assert.equal(legacyCount, 1, '旧数据应保留在备份表');

  // 新表可以正常注册和写成绩
  const uid = gdb.createUser({
    username: '新玩家',
    passwordHash: 'x'.repeat(128),
    salt: 'salt',
    createdAt: new Date().toISOString(),
  });
  gdb.insertScore({ userId: uid, survivalSeconds: 5, kills: 1, endHp: 0, createdAt: new Date().toISOString() });
  const lb = gdb.leaderboard(10);
  assert.equal(lb.length, 1);
  assert.equal(lb[0].username, '新玩家');
  gdb.close();
});
