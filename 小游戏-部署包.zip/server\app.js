'use strict';

const express = require('express');
const crypto = require('crypto');
const path = require('path');

const WEB_DIR = path.join(__dirname, '..', 'web');
const SESSION_COOKIE = 'sid';
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 天
const MAX_SURVIVAL_SECONDS = 86400;
const MAX_KILLS = 200000;
const HP_MAX = 100;

function makeSalt() {
  return crypto.randomBytes(16).toString('hex');
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function safeEqualHex(a, b) {
  const ba = Buffer.from(String(a), 'hex');
  const bb = Buffer.from(String(b), 'hex');
  return ba.length > 0 && ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}

/** 无状态签名会话：payload.signature（base64url + HMAC-SHA256） */
function signSession(uid, secret, ttlMs, now) {
  const payload = Buffer.from(JSON.stringify({ uid, exp: now() + ttlMs }), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifySession(token, secret, now) {
  if (typeof token !== 'string') return null;
  const idx = token.lastIndexOf('.');
  if (idx <= 0) return null;
  const payload = token.slice(0, idx);
  const sig = token.slice(idx + 1);
  const expect = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expect);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  let data;
  try {
    data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  } catch (_) {
    return null;
  }
  if (!Number.isInteger(data.uid) || typeof data.exp !== 'number' || data.exp < now()) return null;
  return data;
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const key = part.slice(0, i).trim();
    if (!key) continue;
    try {
      out[key] = decodeURIComponent(part.slice(i + 1).trim());
    } catch (_) {
      out[key] = part.slice(i + 1).trim();
    }
  }
  return out;
}

/** 用户名：3~16 位，中文/字母/数字/下划线 */
function cleanUsername(raw) {
  if (typeof raw !== 'string') return null;
  const s = raw.trim();
  if (!s) return null;
  const chars = Array.from(s);
  if (chars.length < 3 || chars.length > 16) return null;
  if (!/^[A-Za-z0-9_\u4e00-\u9fa5]+$/.test(s)) return null;
  return s;
}

function checkPassword(raw) {
  return typeof raw === 'string' && raw.length >= 6 && raw.length <= 64;
}

/**
 * 创建 Express 应用。
 * @param {{ db: import('./db').GameDb, sessionSecret?: string, sessionTtlMs?: number,
 *           rateMax?: number, authRateMax?: number, rateWindowMs?: number, now?: () => number }} options
 */
function createApp(options = {}) {
  const { db } = options;
  if (!db) throw new Error('createApp 需要 db 参数');

  const sessionSecret = options.sessionSecret || crypto.randomBytes(32).toString('hex');
  const sessionTtlMs = options.sessionTtlMs ?? SESSION_TTL_MS;
  const now = options.now ?? (() => Date.now());
  const rateMax = options.rateMax ?? (Number(process.env.RATE_MAX) || 5);
  const authRateMax = options.authRateMax ?? (Number(process.env.AUTH_RATE_MAX) || 10);
  const rateWindowMs = options.rateWindowMs ?? 60_000;

  const app = express();
  app.set('trust proxy', process.env.TRUST_PROXY === '1');
  app.disable('x-powered-by');
  app.use(express.json({ limit: '2kb' }));

  function createLimiter(max) {
    const hits = new Map();
    return function limited(key) {
      const t = now();
      const arr = (hits.get(key) || []).filter((ts) => t - ts < rateWindowMs);
      arr.push(t);
      hits.set(key, arr);
      if (hits.size > 10000) {
        for (const [k, list] of hits) {
          if (t - list[list.length - 1] > rateWindowMs) hits.delete(k);
        }
      }
      return arr.length > max;
    };
  }

  const scoreLimited = createLimiter(rateMax);
  const authLimited = createLimiter(authRateMax);

  function currentUser(req) {
    const cookies = parseCookies(req.headers.cookie);
    const token = cookies[SESSION_COOKIE];
    if (!token) return null;
    const data = verifySession(token, sessionSecret, now);
    if (!data) return null;
    const user = db.findUserById(data.uid);
    return user || null;
  }

  function requireAuth(req, res, next) {
    const user = currentUser(req);
    if (!user) return res.status(401).json({ ok: false, error: '请先登录' });
    req.user = user;
    next();
  }

  function setSessionCookie(req, res, uid) {
    const token = signSession(uid, sessionSecret, sessionTtlMs, now);
    res.cookie(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: 'lax',
      path: '/',
      maxAge: sessionTtlMs,
      secure: req.secure,
    });
  }

  app.get('/api/health', (req, res) => {
    res.json({ ok: true, uptime: process.uptime() });
  });

  app.post('/api/register', (req, res) => {
    const ipKey = 'auth:' + (req.ip || 'unknown');
    if (authLimited(ipKey)) {
      return res.status(429).json({ ok: false, error: '操作太频繁，休息一下再试' });
    }
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const username = cleanUsername(body.username);
    if (!username) {
      return res.status(400).json({ ok: false, error: '用户名需为 3~16 位（中文/字母/数字/下划线）' });
    }
    if (!checkPassword(body.password)) {
      return res.status(400).json({ ok: false, error: '密码需为 6~64 位' });
    }
    if (db.findUserByName(username)) {
      return res.status(409).json({ ok: false, error: '这个用户名已经被注册了' });
    }
    const salt = makeSalt();
    const id = db.createUser({
      username,
      passwordHash: hashPassword(body.password, salt),
      salt,
      createdAt: new Date(now()).toISOString(),
    });
    setSessionCookie(req, res, id);
    res.json({ ok: true, data: { user: { id, username } } });
  });

  app.post('/api/login', (req, res) => {
    const ipKey = 'auth:' + (req.ip || 'unknown');
    if (authLimited(ipKey)) {
      return res.status(429).json({ ok: false, error: '操作太频繁，休息一下再试' });
    }
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const username = typeof body.username === 'string' ? body.username.trim() : '';
    const user = username ? db.findUserByName(username) : null;
    if (!user || !checkPassword(body.password) || !safeEqualHex(hashPassword(body.password, user.salt), user.password_hash)) {
      return res.status(401).json({ ok: false, error: '用户名或密码错误' });
    }
    setSessionCookie(req, res, user.id);
    res.json({ ok: true, data: { user: { id: user.id, username: user.username } } });
  });

  app.post('/api/logout', (req, res) => {
    res.clearCookie(SESSION_COOKIE, { path: '/' });
    res.json({ ok: true });
  });

  app.get('/api/me', requireAuth, (req, res) => {
    res.json({
      ok: true,
      data: {
        id: req.user.id,
        username: req.user.username,
        best: db.userBest(req.user.id),
        rank: db.userRank(req.user.id),
      },
    });
  });

  app.post('/api/score', requireAuth, (req, res) => {
    const ipKey = 'score:' + (req.ip || 'unknown');
    if (scoreLimited(ipKey)) {
      return res.status(429).json({ ok: false, error: '提交太频繁，休息一下再试' });
    }
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const survivalSeconds = Number(body.survivalSeconds);
    if (!Number.isFinite(survivalSeconds) || survivalSeconds < 0 || survivalSeconds > MAX_SURVIVAL_SECONDS) {
      return res.status(400).json({ ok: false, error: '存活时间不合法' });
    }
    const kills = Number(body.kills);
    if (!Number.isInteger(kills) || kills < 0 || kills > MAX_KILLS) {
      return res.status(400).json({ ok: false, error: '击杀数不合法' });
    }
    const endHp = Number(body.endHp);
    if (!Number.isInteger(endHp) || endHp < 0 || endHp > HP_MAX) {
      return res.status(400).json({ ok: false, error: '剩余血量不合法' });
    }

    const sessionSeconds = Math.round(survivalSeconds * 10) / 10;
    const id = db.insertScore({
      userId: req.user.id,
      survivalSeconds: sessionSeconds,
      kills,
      endHp,
      createdAt: new Date(now()).toISOString(),
    });
    res.json({
      ok: true,
      data: {
        accepted: true,
        id,
        best: db.userBest(req.user.id),
        rank: db.userRank(req.user.id),
      },
    });
  });

  app.get('/api/leaderboard', (req, res) => {
    const raw = parseInt(req.query.limit, 10);
    const limit = Math.max(1, Math.min(100, Number.isFinite(raw) ? raw : 50));
    res.json({ ok: true, data: { items: db.leaderboard(limit), total: db.rankedUserCount() } });
  });

  // 静态游戏页面
  app.use(express.static(WEB_DIR, { index: 'index.html' }));

  app.use('/api', (req, res) => {
    res.status(404).json({ ok: false, error: '接口不存在' });
  });

  // 请求体解析失败等错误
  app.use((err, req, res, next) => {
    if (err && (err.type === 'entity.parse.failed' || err.type === 'entity.too.large')) {
      return res.status(400).json({ ok: false, error: '请求体不合法' });
    }
    console.error('[error]', err);
    res.status(500).json({ ok: false, error: '服务器开小差了' });
  });

  return app;
}

module.exports = { createApp };
