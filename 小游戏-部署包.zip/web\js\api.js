'use strict';

/**
 * 服务端 API 客户端（账号 + 排行榜）。
 */
const API = {
  async _json(res) {
    try {
      return await res.json();
    } catch (_) {
      return { ok: false, error: `服务器返回异常（HTTP ${res.status}）` };
    }
  },

  /** 当前登录用户；未登录返回 null */
  async me() {
    const res = await fetch('/api/me', { cache: 'no-store', credentials: 'same-origin' });
    if (res.status === 401) return null;
    const json = await this._json(res);
    if (!json.ok) throw new Error(json.error || '获取账号信息失败');
    return json.data;
  },

  async register(username, password) {
    const res = await fetch('/api/register', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const json = await this._json(res);
    if (!res.ok || !json.ok) throw new Error(json.error || '注册失败');
    return json.data;
  },

  async login(username, password) {
    const res = await fetch('/api/login', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const json = await this._json(res);
    if (!res.ok || !json.ok) throw new Error(json.error || '登录失败');
    return json.data;
  },

  async logout() {
    try {
      await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' });
    } catch (_) {
      /* 忽略网络错误 */
    }
  },

  /**
   * 拉取排行榜（每人一条最好成绩）。
   * @returns {Promise<{items: Array, total: number}>}
   */
  async fetchLeaderboard(limit = 50) {
    const res = await fetch(`/api/leaderboard?limit=${encodeURIComponent(limit)}`, {
      cache: 'no-store',
      credentials: 'same-origin',
    });
    const json = await this._json(res);
    if (!res.ok || !json.ok) throw new Error(json.error || '排行榜加载失败');
    return json.data;
  },

  /**
   * 提交一局成绩（自动绑定当前登录账号）。
   * @param {{survivalSeconds: number, kills: number, endHp: number}} payload
   * @returns {Promise<{accepted: boolean, id: number, best: object, rank: number}>}
   */
  async submitScore(payload) {
    const res = await fetch('/api/score', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const json = await this._json(res);
    if (!res.ok || !json.ok) throw new Error(json.error || '提交失败');
    return json.data;
  },
};
