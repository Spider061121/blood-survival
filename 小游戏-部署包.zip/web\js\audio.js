'use strict';

/**
 * 声音引擎（Web Audio 实时合成，无任何音频文件）：
 *  - BGM：激烈电子风，150BPM 左右，失真贝斯 + 四四拍鼓点 + 琶音主旋律，
 *         节奏随存活时间加快、主旋律随时间加入。
 *  - 音效：开火 / 命中 / 击杀 / 回血 / 受击 / 结算。
 *  - 浏览器不支持 AudioContext 时全部静默（不影响游戏）。
 */
(() => {
  'use strict';

  const AC = window.AudioContext || window.webkitAudioContext;
  const MUTE_KEY = 'blood-survival:muted';

  let ctx = null;
  let master = null;
  let musicBus = null;
  let sfxBus = null;
  let muted = false;
  let bgmOn = false;
  let timer = null;
  let step = 0;
  let nextTime = 0;
  let intensity = 0;

  try {
    muted = localStorage.getItem(MUTE_KEY) === '1';
  } catch (_) {
    /* ignore */
  }

  function makeDistortionCurve(amount) {
    const k = amount;
    const n = 1024;
    const curve = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = (i * 2) / n - 1;
      curve[i] = ((3 + k) * x * 20 * Math.PI) / (Math.PI + k * Math.abs(x));
    }
    return curve;
  }

  /** 创建/恢复音频上下文（必须在用户手势里首次调用） */
  function ensure() {
    if (!AC) return null;
    if (!ctx) {
      try {
        ctx = new AC();
        master = ctx.createGain();
        master.gain.value = muted ? 0 : 0.9;
        master.connect(ctx.destination);

        sfxBus = ctx.createGain();
        sfxBus.gain.value = 0.55;
        sfxBus.connect(master);

        musicBus = ctx.createGain();
        musicBus.gain.value = 0.16;
        const shaper = ctx.createWaveShaper();
        shaper.curve = makeDistortionCurve(70);
        shaper.oversample = '2x';
        musicBus.connect(shaper);
        shaper.connect(master);
      } catch (err) {
        ctx = null;
      }
    }
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  }

  function now() {
    return ctx ? ctx.currentTime : 0;
  }

  /** 单音：频率从 f0 滑到 f1 */
  function blip(type, f0, f1, dur, vol, bus, when) {
    if (!ctx) return;
    const t = when ?? now();
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) osc.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(bus);
    osc.start(t);
    osc.stop(t + dur + 0.03);
  }

  /** 噪声爆发：用于鼓、命中、受击 */
  function noiseBurst(dur, vol, filterType, freq, bus, when) {
    if (!ctx) return;
    const t = when ?? now();
    const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(bus);
    src.start(t);
    src.stop(t + dur + 0.02);
  }

  /* ============ 鼓组 ============ */
  function kick(t) {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(42, t + 0.12);
    g.gain.setValueAtTime(0.9, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    osc.connect(g);
    g.connect(musicBus);
    osc.start(t);
    osc.stop(t + 0.18);
  }

  function snare(t) {
    noiseBurst(0.1, 0.4, 'highpass', 1500, musicBus, t);
    blip('triangle', 190, 120, 0.08, 0.22, musicBus, t);
  }

  function hat(t, s16) {
    const accent = s16 % 4 === 0 ? 0.2 : 0.09;
    noiseBurst(0.035, accent, 'highpass', 7000, musicBus, t);
  }

  /* ============ 旋律声部 ============ */
  // E 小调：失真贝斯 + 琶音主旋律
  const BASS_NOTES = [41.2, 41.2, 55.0, 49.0]; // E1 E1 A1 G1
  const LEAD_NOTES = [329.6, 392.0, 440.0, 493.9, 659.2, 493.9, 440.0, 392.0]; // Em 琶音

  function bassNote(t, bar, s16) {
    if (s16 % 2 !== 0) return; // 八分音符
    const note = BASS_NOTES[(s16 / 2 + bar) % 4];
    const dur = 0.15;
    const osc = ctx.createOscillator();
    const filt = ctx.createBiquadFilter();
    const g = ctx.createGain();
    filt.type = 'lowpass';
    filt.frequency.setValueAtTime(260, t);
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(note, t);
    g.gain.setValueAtTime(0.5, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(filt);
    filt.connect(g);
    g.connect(musicBus);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  function leadNote(t, bar, s16) {
    if (intensity < 18) return; // 开局 18 秒后加入主旋律
    if (s16 % 2 !== 0) return;
    const idx = (s16 / 2 + bar * 2) % LEAD_NOTES.length;
    const octave = bar % 4 >= 2 ? 2 : 1;
    const note = LEAD_NOTES[idx] * octave;
    blip('square', note, note, 0.09, 0.1, musicBus, t);
  }

  /* ============ 节拍调度 ============ */
  function bpm() {
    return Math.min(172, 138 + Math.max(0, intensity) * 0.35);
  }

  function playStep(s, t) {
    const bar = Math.floor(s / 16);
    const s16 = s % 16;
    if (s16 % 4 === 0) kick(t);
    if (s16 === 4 || s16 === 12) snare(t);
    hat(t, s16);
    bassNote(t, bar, s16);
    leadNote(t, bar, s16);
  }

  function schedule() {
    if (!ctx || !bgmOn) return;
    const stepDur = 60 / bpm() / 4;
    while (nextTime < ctx.currentTime + 0.12) {
      playStep(step, nextTime);
      nextTime += stepDur;
      step = (step + 1) % 64;
    }
  }

  function startBgm() {
    if (!ensure() || bgmOn) return;
    bgmOn = true;
    step = 0;
    nextTime = ctx.currentTime + 0.1;
    schedule();
    timer = setInterval(schedule, 40);
  }

  function stopBgm() {
    bgmOn = false;
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  }

  function setIntensity(t) {
    intensity = Math.max(0, Number(t) || 0);
  }

  function setMuted(v) {
    muted = !!v;
    try {
      localStorage.setItem(MUTE_KEY, muted ? '1' : '0');
    } catch (_) {
      /* ignore */
    }
    if (master) master.gain.setTargetAtTime(muted ? 0 : 0.9, now() + 0.01, 0.02);
  }

  const Sound = {
    ensure,
    startBgm,
    stopBgm,
    setIntensity,
    setMuted,
    toggleMute() {
      setMuted(!muted);
      return muted;
    },
    isMuted() {
      return muted;
    },

    click() {
      if (!ensure()) return;
      blip('square', 900, 700, 0.03, 0.05, sfxBus);
    },
    shoot() {
      if (!ensure()) return;
      blip('square', 880, 300, 0.05, 0.06, sfxBus);
    },
    hit() {
      if (!ensure()) return;
      noiseBurst(0.04, 0.07, 'highpass', 2500, sfxBus);
    },
    kill() {
      if (!ensure()) return;
      blip('sawtooth', 260, 50, 0.16, 0.11, sfxBus);
      noiseBurst(0.08, 0.1, 'lowpass', 900, sfxBus);
    },
    heal() {
      if (!ensure()) return;
      blip('sine', 523, 784, 0.1, 0.13, sfxBus);
    },
    damage() {
      if (!ensure()) return;
      blip('sawtooth', 130, 45, 0.22, 0.28, sfxBus);
      noiseBurst(0.12, 0.22, 'lowpass', 500, sfxBus);
    },
    gameover() {
      if (!ensure()) return;
      blip('sawtooth', 320, 55, 1.1, 0.2, sfxBus);
      noiseBurst(0.5, 0.14, 'lowpass', 700, sfxBus);
    },
  };

  window.Sound = Sound;
})();
