'use strict';

/**
 * 游戏逻辑冒烟测试：用最小 DOM/Canvas 桩 + 手动驱动 requestAnimationFrame，
 * 在 Node 里跑真实游戏循环（含登录态、提交成绩），验证刷怪、开火、击杀、掉血、结算、重开。
 *
 * 用法：node tools/sim-game.js
 */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');

const DIR = path.join(__dirname, '..');
const API_SRC = fs.readFileSync(path.join(DIR, 'web', 'js', 'api.js'), 'utf8');
const AUDIO_SRC = fs.readFileSync(path.join(DIR, 'web', 'js', 'audio.js'), 'utf8');
const GAME_SRC = fs.readFileSync(path.join(DIR, 'web', 'js', 'game.js'), 'utf8');

const noop = () => {};

function makeCtx() {
  return new Proxy(
    {},
    {
      get(target, prop) {
        if (prop === 'createRadialGradient' || prop === 'createLinearGradient') {
          return () => ({ addColorStop: noop });
        }
        if (prop === 'measureText') return () => ({ width: 20 });
        if (prop in target) return target[prop];
        return noop;
      },
      set(target, prop, value) {
        target[prop] = value;
        return true;
      },
    }
  );
}

const ctx = makeCtx();

function makeElement(id) {
  const listeners = {};
  const el = {
    id,
    tagName: 'DIV',
    style: {},
    value: '',
    textContent: '',
    innerHTML: '',
    disabled: false,
    className: '',
    classList: {
      set: new Set(),
      add(c) {
        this.set.add(c);
      },
      remove(c) {
        this.set.delete(c);
      },
      toggle(c, force) {
        const want = force === undefined ? !this.set.has(c) : !!force;
        if (want) this.set.add(c);
        else this.set.delete(c);
        return want;
      },
      contains(c) {
        return this.set.has(c);
      },
    },
    _w: 960,
    _h: 600,
    get width() {
      return this._w;
    },
    set width(v) {
      this._w = v;
    },
    get height() {
      return this._h;
    },
    set height(v) {
      this._h = v;
    },
    addEventListener(type, fn) {
      (listeners[type] = listeners[type] || []).push(fn);
    },
    removeEventListener() {},
    getBoundingClientRect() {
      return { left: 0, top: 0, width: 960, height: 600, right: 960, bottom: 600 };
    },
    getContext() {
      return ctx;
    },
    dispatch(type, evt) {
      const list = listeners[type] || [];
      for (const fn of list) fn(evt || { preventDefault: noop });
    },
  };
  return el;
}

const elements = new Map();
function getEl(id) {
  if (!elements.has(id)) elements.set(id, makeElement(id));
  return elements.get(id);
}

// 手动驱动的 rAF 队列
let rafQueue = [];
const localStorageStub = {
  store: {},
  getItem(k) {
    return Object.prototype.hasOwnProperty.call(this.store, k) ? this.store[k] : null;
  },
  setItem(k, v) {
    this.store[k] = String(v);
  },
  removeItem(k) {
    delete this.store[k];
  },
};

const documentStub = {
  hidden: false,
  visibilityState: 'visible',
  getElementById: getEl,
  addEventListener: noop,
  removeEventListener: noop,
};

const meStub = { id: 1, username: '测试玩家', best: null, rank: null };
const fetchStub = (url) => {
  const u = String(url);
  if (u.includes('/api/me')) {
    return Promise.resolve({ status: 200, ok: true, json: async () => ({ ok: true, data: meStub }) });
  }
  if (u.includes('/api/score')) {
    return Promise.resolve({
      status: 200,
      ok: true,
      json: async () => ({
        ok: true,
        data: { accepted: true, id: 1, rank: 1, best: { survivalSeconds: 100, kills: 5, endHp: 0, createdAt: '2026-01-01T00:00:00.000Z' } },
      }),
    });
  }
  if (u.includes('/api/leaderboard')) {
    return Promise.resolve({
      status: 200,
      ok: true,
      json: async () => ({ ok: true, data: { items: [], total: 0 } }),
    });
  }
  return Promise.resolve({ status: 404, ok: false, json: async () => ({ ok: false, error: 'not found' }) });
};

const sandbox = {
  window: null,
  document: documentStub,
  localStorage: localStorageStub,
  location: { reload: noop },
  fetch: fetchStub,
  requestAnimationFrame(cb) {
    rafQueue.push(cb);
    return rafQueue.length;
  },
  cancelAnimationFrame: noop,
  addEventListener: noop,
  removeEventListener: noop,
  devicePixelRatio: 1,
  setTimeout,
  clearTimeout,
  setInterval() {
    return 0;
  },
  clearInterval: noop,
  console,
  performance: { now: () => Date.now() },
  Date,
  Math,
  JSON,
  Number,
  String,
  Array,
  Object,
  Set,
  Map,
  Promise,
  Float32Array,
  Infinity,
  NaN,
  isFinite,
  parseInt,
  parseFloat,
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(API_SRC, sandbox, { filename: 'api.js' });
vm.runInContext(AUDIO_SRC, sandbox, { filename: 'audio.js' });
vm.runInContext(GAME_SRC, sandbox, { filename: 'game.js' });

const game = sandbox.window.__BS_GAME;
assert.ok(game, 'game.js 应该暴露 window.__BS_GAME');

const els = {
  btnStart: getEl('btnStart'),
  btnAgain: getEl('btnAgain'),
  authScreen: getEl('authScreen'),
  startScreen: getEl('startScreen'),
  gameOverScreen: getEl('gameOverScreen'),
  submitState: getEl('submitState'),
  userName: getEl('userName'),
  finalTime: getEl('finalTime'),
  finalKills: getEl('finalKills'),
};

let now = 0;
const FRAME = 1000 / 60;
function tick(n = 1) {
  for (let i = 0; i < n; i++) {
    now += FRAME;
    const queue = rafQueue;
    rafQueue = [];
    for (const cb of queue) cb(now);
  }
}
function flush() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

(async () => {
  // ---- 1. 等登录态初始化完成：fetch 桩返回已登录用户，应直接进入游戏界面 ----
  await flush();
  assert.equal(game.state, 'ready', '初始应为 ready');
  assert.equal(els.authScreen.classList.contains('hidden'), true, '已登录应隐藏登录界面');
  assert.equal(els.startScreen.classList.contains('hidden'), false, '已登录应显示开始界面');
  assert.equal(els.userName.textContent, '测试玩家');

  // ---- 2. 开始游戏 ----
  els.btnStart.dispatch('click');
  assert.equal(game.state, 'playing', '点击开始后应为 playing');
  assert.equal(game.hp, 100);

  // ---- 3. 跑 3 秒：应刷出怪物 ----
  tick(180);
  assert.ok(game.t > 2.5, `时间应推进，实际 t=${game.t.toFixed(2)}`);
  assert.ok(game.monsters.length > 0, `3 秒后应有怪物，实际 ${game.monsters.length}`);

  // ---- 4. 跑 15 秒：应有击杀（自动开火 + 击杀回血路径） ----
  tick(720);
  assert.ok(game.kills > 0, `15 秒后应有击杀，实际 ${game.kills}`);
  assert.ok(game.hp <= 100, '血量不超过上限');
  assert.ok(game.monsters.length <= 42, '怪物数量不超过上限');

  // ---- 5. 长时间挂机：怪物越积越多，必然被撞掉血，最终结算 ----
  let minHp = game.hp;
  let sawDamage = false;
  let sawOver = false;
  for (let s = 0; s < 90 * 60; s++) {
    tick(1);
    if (game.hp < minHp) {
      sawDamage = true;
      minHp = game.hp;
    }
    if (game.state === 'over') {
      sawOver = true;
      break;
    }
  }
  assert.ok(sawDamage, '长时间挂机应被打掉血（受击逻辑生效）');
  assert.ok(sawOver, '血量归零后应进入结算状态');
  assert.match(els.finalTime.textContent, /^\d{2}:\d{2}$/, '结算面板应有存活时间');
  assert.ok(Number(els.finalKills.textContent) >= 0, '结算面板应有击杀数');
  assert.equal(els.gameOverScreen.classList.contains('hidden'), false, '结算面板应显示');

  // 结算后自动提交成绩
  await flush();
  assert.match(els.submitState.textContent, /已记录/, '结算后应自动提交成绩成功');

  // ---- 6. 再来一局 ----
  els.btnAgain.dispatch('click');
  assert.equal(game.state, 'playing', '再来一局应回到 playing');
  assert.equal(game.t, 0, '时间应重置');
  assert.equal(game.hp, 100, '血量应重置');
  assert.equal(game.kills, 0, '击杀应重置');
  tick(60);
  assert.ok(game.t > 0.9, '重开后时间正常推进');

  console.log('✅ 游戏逻辑冒烟测试通过：登录态、刷怪、开火、击杀、掉血、自动提交、结算、重开 全部正常');
})().catch((err) => {
  console.error('❌ 冒烟测试失败:', err);
  process.exit(1);
});
