(() => {
  'use strict';

  /* ================= 数值配置 ================= */
  const HP_MAX = 100;
  const TAU = Math.PI * 2;
  const PLAYER_SPEED = 320;
  const FIRE_INTERVAL = 0.32;
  const IFRAME_SECONDS = 0.6;
  const PACK_EVERY_KILLS = 5;
  const MAX_MONSTERS = 42;

  const rnd = (a, b) => a + Math.random() * (b - a);
  const rndInt = (a, b) => Math.floor(rnd(a, b + 1));
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  /** 受击伤害随存活时间提升：10 起步，每 15 秒 +3，封顶 45 */
  const damageAt = (t) => Math.min(45, 10 + Math.floor(t / 15) * 3);
  /** 血包回血量随时长提升 */
  const healValueAt = (t) => (t < 30 ? 15 : t < 60 ? 20 : 25);
  /** 怪物移速随时间增长 */
  const monsterSpeedAt = (t) => Math.min(260, 65 + t * 0.7);

  const $ = (id) => document.getElementById(id);

  const els = {
    canvas: $('game'),
    hpFill: $('hpFill'),
    hpText: $('hpText'),
    timeText: $('timeText'),
    killText: $('killText'),
    dangerText: $('dangerText'),
    authScreen: $('authScreen'),
    startScreen: $('startScreen'),
    gameOverScreen: $('gameOverScreen'),
    tabLogin: $('tabLogin'),
    tabRegister: $('tabRegister'),
    authUsername: $('authUsername'),
    authPassword: $('authPassword'),
    authConfirm: $('authConfirm'),
    authConfirmField: $('authConfirmField'),
    authState: $('authState'),
    btnAuthSubmit: $('btnAuthSubmit'),
    btnStart: $('btnStart'),
    btnAgain: $('btnAgain'),
    btnRetry: $('btnRetry'),
    submitState: $('submitState'),
    finalTime: $('finalTime'),
    finalKills: $('finalKills'),
    leaderboardPanel: $('leaderboardPanel'),
    lbList: $('lbList'),
    lbTotal: $('lbTotal'),
    myBest: $('myBest'),
    btnLeaderboard: $('btnLeaderboard'),
    btnCloseLeaderboard: $('btnCloseLeaderboard'),
    userChip: $('userChip'),
    userName: $('userName'),
    btnLogout: $('btnLogout'),
    btnSound: $('btnSound'),
  };

  const ctx = els.canvas.getContext('2d');

  /** 声音引擎（web/js/audio.js），加载失败时降级为空操作 */
  const Sound = window.Sound || {
    startBgm() {},
    stopBgm() {},
    setIntensity() {},
    toggleMute() { return false; },
    isMuted() { return false; },
    click() {},
    shoot() {},
    hit() {},
    kill() {},
    heal() {},
    damage() {},
    gameover() {},
  };

  /* ================= 状态 ================= */
  const game = {
    state: 'ready', // ready | playing | over
    t: 0,
    hp: HP_MAX,
    kills: 0,
    iframe: 0,
    fireCd: 0,
    aim: -Math.PI / 2,
    W: 0,
    H: 0,
    dpr: 1,
    player: { x: 0, y: 0, r: 13 },
    monsters: [],
    bullets: [],
    packs: [],
    particles: [],
    floats: [],
    stars: [],
    keys: new Set(),
    pointer: { x: 0, y: 0, active: false },
    spawnCd: 0.6,
    kickStreak: 0,
    shake: 0,
    flash: 0,
    last: 0,
  };

  /** 当前登录用户：{ id, username, best, rank } */
  let me = null;

  function formatTime(sec) {
    const s = Math.max(0, Math.floor(sec));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const ss = String(s % 60).padStart(2, '0');
    return h > 0 ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${String(m).padStart(2, '0')}:${ss}`;
  }

  function esc(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[c]));
  }

  /* ================= 画布尺寸 ================= */
  function resize() {
    const rect = els.canvas.getBoundingClientRect();
    game.dpr = Math.min(window.devicePixelRatio || 1, 2);
    game.W = Math.max(300, rect.width);
    game.H = Math.max(220, rect.height);
    els.canvas.width = Math.round(game.W * game.dpr);
    els.canvas.height = Math.round(game.H * game.dpr);
    ctx.setTransform(game.dpr, 0, 0, game.dpr, 0, 0);
    initStars();

    const p = game.player;
    if (p.x === 0 && p.y === 0) {
      p.x = game.W / 2;
      p.y = game.H / 2;
    } else {
      p.x = clamp(p.x, p.r, game.W - p.r);
      p.y = clamp(p.y, p.r, game.H - p.r);
    }
  }

  function initStars() {
    const count = Math.round((game.W * game.H) / 9000);
    game.stars = Array.from({ length: count }, () => ({
      x: Math.random() * game.W,
      y: Math.random() * game.H,
      r: rnd(0.4, 1.6),
      tw: rnd(0, TAU),
      sp: rnd(0.2, 0.9),
    }));
  }

  /* ================= 游戏流程 ================= */
  function startGame() {
    if (!me) {
      showAuth();
      return;
    }
    Sound.click();
    Sound.startBgm();
    Sound.setIntensity(0);

    game.state = 'playing';
    game.t = 0;
    game.hp = HP_MAX;
    game.kills = 0;
    game.iframe = 0;
    game.fireCd = 0;
    game.aim = -Math.PI / 2;
    game.monsters.length = 0;
    game.bullets.length = 0;
    game.packs.length = 0;
    game.particles.length = 0;
    game.floats.length = 0;
    game.spawnCd = 0.6;
    game.kickStreak = 0;
    game.shake = 0;
    game.flash = 0;
    game.last = 0;
    game.player.x = game.W / 2;
    game.player.y = game.H / 2;
    game.pointer.active = false;

    els.startScreen.classList.add('hidden');
    els.gameOverScreen.classList.add('hidden');
    els.leaderboardPanel.classList.add('hidden');
    els.submitState.textContent = '';
    els.submitState.className = 'submit-state';
    updateHud();
  }

  function endGame() {
    if (game.state !== 'playing') return;
    game.state = 'over';
    game.iframe = 0;

    els.finalTime.textContent = formatTime(game.t);
    els.finalKills.textContent = String(game.kills);
    els.submitState.textContent = '正在记录成绩…';
    els.submitState.className = 'submit-state';
    els.btnRetry.classList.add('hidden');
    els.btnAgain.disabled = false;
    els.gameOverScreen.classList.remove('hidden');
    updateHud();

    Sound.stopBgm();
    Sound.gameover();
    submitResult();
  }

  async function submitResult() {
    if (!me || game.state !== 'over') return;
    els.btnRetry.classList.add('hidden');
    els.btnRetry.disabled = true;
    try {
      const data = await API.submitScore({
        survivalSeconds: Math.round(game.t * 10) / 10,
        kills: game.kills,
        endHp: 0,
      });
      me.best = data.best;
      me.rank = data.rank;
      els.submitState.textContent = `✅ 已记录到「${me.username}」。个人最好：${formatTime(data.best.survivalSeconds)}（击杀 ${data.best.kills}，第 ${data.rank} 名）`;
      els.submitState.className = 'submit-state ok';
      refreshLeaderboard();
      updateMyBestLine();
    } catch (err) {
      els.submitState.textContent = `记录失败：${err.message}`;
      els.submitState.className = 'submit-state error';
      els.btnRetry.classList.remove('hidden');
      els.btnRetry.disabled = false;
    }
  }

  /* ================= 账号与登录 ================= */
  function showAuth() {
    els.authScreen.classList.remove('hidden');
    els.startScreen.classList.add('hidden');
    els.gameOverScreen.classList.add('hidden');
  }

  function enterGameUI(user) {
    me = user;
    els.authScreen.classList.add('hidden');
    els.startScreen.classList.remove('hidden');
    els.gameOverScreen.classList.add('hidden');
    els.userChip.classList.remove('hidden');
    els.userName.textContent = me.username;
    els.btnLeaderboard.classList.remove('hidden');
    updateMyBestLine();
  }

  async function initAuth() {
    try {
      const user = await API.me();
      if (user) enterGameUI(user);
      else showAuth();
    } catch (err) {
      els.authState.textContent = `无法连接服务器，请刷新页面重试（${err.message}）`;
      els.authState.className = 'submit-state error';
    }
  }

  let authMode = 'login';

  function setAuthMode(mode) {
    authMode = mode;
    els.tabLogin.classList.toggle('active', mode === 'login');
    els.tabRegister.classList.toggle('active', mode === 'register');
    els.authConfirmField.classList.toggle('hidden', mode !== 'register');
    els.btnAuthSubmit.textContent = mode === 'login' ? '登录' : '注册并登录';
    els.authState.textContent = '';
    els.authState.className = 'submit-state';
  }

  async function submitAuth() {
    const username = els.authUsername.value.trim();
    const password = els.authPassword.value;
    const confirm = els.authConfirm.value;

    if (!username || !password) {
      els.authState.textContent = '请输入用户名和密码';
      els.authState.className = 'submit-state error';
      return;
    }
    if (authMode === 'register' && password !== confirm) {
      els.authState.textContent = '两次输入的密码不一致';
      els.authState.className = 'submit-state error';
      return;
    }

    Sound.click();
    els.btnAuthSubmit.disabled = true;
    try {
      if (authMode === 'login') await API.login(username, password);
      else await API.register(username, password);
      location.reload();
    } catch (err) {
      els.authState.textContent = err.message;
      els.authState.className = 'submit-state error';
      els.btnAuthSubmit.disabled = false;
    }
  }

  async function logout() {
    try {
      await API.logout();
    } catch (_) {
      /* ignore */
    }
    location.reload();
  }

  /* ================= 排行榜界面 ================= */
  let lbLoading = false;

  function openLeaderboard() {
    els.leaderboardPanel.classList.remove('hidden');
    refreshLeaderboard();
  }

  function closeLeaderboard() {
    els.leaderboardPanel.classList.add('hidden');
  }

  async function updateMyBestLine() {
    if (!me) {
      els.myBest.textContent = '';
      return;
    }
    if (!me.best) {
      els.myBest.textContent = '你还没有成绩，玩一局吧！';
      return;
    }
    els.myBest.textContent = `你的个人最好：${formatTime(me.best.survivalSeconds)} · 击杀 ${me.best.kills} · 第 ${me.rank} 名`;
  }

  async function refreshLeaderboard() {
    if (lbLoading) return;
    lbLoading = true;
    els.lbList.innerHTML = '<li class="empty">加载中…</li>';
    try {
      const data = await API.fetchLeaderboard(50);
      renderLeaderboard(data);
    } catch (err) {
      els.lbList.innerHTML = `<li class="empty">排行榜加载失败：${esc(err.message)}</li>`;
      els.lbTotal.textContent = '';
    } finally {
      lbLoading = false;
    }
    updateMyBestLine();
  }

  function renderLeaderboard(data) {
    els.lbTotal.textContent = data.total ? `共 ${data.total} 位玩家上榜` : '';
    if (!data.items || !data.items.length) {
      els.lbList.innerHTML = '<li class="empty">还没有人上榜，快来做第一个！</li>';
      return;
    }
    const medal = (n) => (n === 1 ? '🥇' : n === 2 ? '🥈' : n === 3 ? '🥉' : String(n));
    els.lbList.innerHTML = data.items
      .map((it, idx) => {
        const isMe = me && it.username === me.username;
        return `
        <li class="lb-item${idx === 0 ? ' top1' : ''}${isMe ? ' me' : ''}">
          <span class="rank">${medal(idx + 1)}</span>
          <span class="name" title="${esc(it.username)}">${esc(it.username)}</span>
          <span class="time">${formatTime(it.survivalSeconds)}</span>
          <span class="kills">☠ ${it.kills}</span>
        </li>`;
      })
      .join('');
  }

  /* ================= 更新逻辑 ================= */
  function update(dt) {
    game.t += dt;
    Sound.setIntensity(game.t);
    if (game.iframe > 0) game.iframe -= dt;
    if (game.flash > 0) game.flash = Math.max(0, game.flash - dt * 3);
    game.shake = Math.max(0, game.shake - dt * 40);

    updatePlayer(dt);

    // 自动开火
    game.fireCd -= dt;
    if (game.fireCd <= 0) {
      const target = nearestMonster(560);
      if (target) {
        game.fireCd = FIRE_INTERVAL;
        fireAt(target);
      } else {
        game.fireCd = 0.1;
      }
    }

    // 刷怪
    game.spawnCd -= dt;
    if (game.spawnCd <= 0 && game.monsters.length < MAX_MONSTERS) {
      spawnMonster();
      const interval = Math.max(0.38, 1.15 - game.t * 0.006);
      game.spawnCd = interval * rnd(0.7, 1.3);
    }

    updateMonsters(dt);
    updateBullets(dt);
    updatePacks(dt);
    updateEffects(dt);

    if (game.hp <= 0) endGame();
  }

  function updatePlayer(dt) {
    const p = game.player;
    let mx = 0;
    let my = 0;
    if (game.keys.has('a') || game.keys.has('arrowleft')) mx -= 1;
    if (game.keys.has('d') || game.keys.has('arrowright')) mx += 1;
    if (game.keys.has('w') || game.keys.has('arrowup')) my -= 1;
    if (game.keys.has('s') || game.keys.has('arrowdown')) my += 1;

    if (mx || my) {
      const len = Math.hypot(mx, my) || 1;
      p.x += (mx / len) * PLAYER_SPEED * dt;
      p.y += (my / len) * PLAYER_SPEED * dt;
    } else if (game.pointer.active) {
      const dx = game.pointer.x - p.x;
      const dy = game.pointer.y - p.y;
      const d = Math.hypot(dx, dy);
      if (d > 3) {
        const step = Math.min(d, PLAYER_SPEED * 1.3 * dt);
        p.x += (dx / d) * step;
        p.y += (dy / d) * step;
      }
    }
    p.x = clamp(p.x, p.r, game.W - p.r);
    p.y = clamp(p.y, p.r, game.H - p.r);
  }

  function nearestMonster(maxDist) {
    let best = null;
    let bestD = maxDist;
    for (const m of game.monsters) {
      const d = Math.hypot(m.x - game.player.x, m.y - game.player.y);
      if (d < bestD) {
        bestD = d;
        best = m;
      }
    }
    return best;
  }

  function fireAt(target) {
    const p = game.player;
    const ang = Math.atan2(target.y - p.y, target.x - p.x);
    game.aim = ang;
    game.bullets.push({
      x: p.x + Math.cos(ang) * 16,
      y: p.y + Math.sin(ang) * 16,
      vx: Math.cos(ang) * 760,
      vy: Math.sin(ang) * 760,
      r: 3,
      life: 1.6,
    });
    Sound.shoot();
  }

  function spawnMonster() {
    const fast = game.t > 40 && Math.random() < 0.35;
    const edge = Math.floor(Math.random() * 4);
    const pad = 30;
    let x;
    let y;
    if (edge === 0) {
      x = rnd(0, game.W);
      y = -pad;
    } else if (edge === 1) {
      x = game.W + pad;
      y = rnd(0, game.H);
    } else if (edge === 2) {
      x = rnd(0, game.W);
      y = game.H + pad;
    } else {
      x = -pad;
      y = rnd(0, game.H);
    }

    const big = !fast && Math.random() < 0.3;
    const r = fast ? rnd(10, 13) : big ? rnd(15, 19) : rnd(11, 15);
    const hp = fast ? 2 : big ? 4 : 3;
    game.monsters.push({
      x,
      y,
      r,
      hp,
      maxHp: hp,
      speed: monsterSpeedAt(game.t) * (fast ? 1.7 : 0.9) * rnd(0.85, 1.15),
      flash: 0,
      type: fast ? 'fast' : big ? 'big' : 'normal',
      wob: rnd(0, TAU),
      wobAmp: rnd(0, 0.35),
    });
  }

  function updateMonsters(dt) {
    const p = game.player;
    for (const m of game.monsters) {
      m.flash = Math.max(0, m.flash - dt * 6);
      m.wob += dt * 2;

      const dx = p.x - m.x;
      const dy = p.y - m.y;
      const d = Math.hypot(dx, dy) || 1;
      const nx = dx / d;
      const ny = dy / d;
      const wob = Math.sin(m.wob) * m.wobAmp * m.speed * dt * 1.5;

      m.x += nx * m.speed * dt - ny * wob;
      m.y += ny * m.speed * dt + nx * wob;

      const d2 = Math.hypot(p.x - m.x, p.y - m.y);
      if (game.iframe <= 0 && d2 < m.r + p.r) {
        takeDamage(m);
        const push = m.r + p.r + 6 - d2;
        m.x -= nx * push;
        m.y -= ny * push;
      }
    }
  }

  function takeDamage(m) {
    const dmg = damageAt(game.t);
    game.hp = Math.max(0, game.hp - dmg);
    game.iframe = IFRAME_SECONDS;
    game.shake = 14;
    game.flash = 0.35;
    addFloat(game.player.x, game.player.y - 26, `-${dmg}`, '#ff5c5c');
    burst(game.player.x, game.player.y, 10, '#ff5c5c');
    m.flash = 1;
    Sound.damage();
    updateHud();
  }

  function updateBullets(dt) {
    for (let i = game.bullets.length - 1; i >= 0; i--) {
      const b = game.bullets[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;

      let dead = b.life <= 0 || b.x < -20 || b.x > game.W + 20 || b.y < -20 || b.y > game.H + 20;
      if (!dead) {
        for (const m of game.monsters) {
          if (m.hp <= 0) continue;
          if (Math.hypot(m.x - b.x, m.y - b.y) < m.r + b.r) {
            m.hp -= 1;
            m.flash = 1;
            burst(b.x, b.y, 4, '#7fe7ff');
            Sound.hit();
            dead = true;
            if (m.hp <= 0) killMonster(m);
            break;
          }
        }
      }
      if (dead) game.bullets.splice(i, 1);
    }
    game.monsters = game.monsters.filter((m) => m.hp > 0);
  }

  function killMonster(m) {
    game.kills += 1;
    game.kickStreak += 1;

    const heal = rndInt(1, 3);
    game.hp = Math.min(HP_MAX, game.hp + heal);
    addFloat(m.x, m.y - m.r - 8, `+${heal}`, '#6dff9a');
    burst(m.x, m.y, m.type === 'big' ? 18 : 10, m.type === 'fast' ? '#ffb347' : '#ff6f91');
    Sound.kill();

    if (game.kickStreak >= PACK_EVERY_KILLS) {
      game.kickStreak = 0;
      spawnPack();
    }
    updateHud();
  }

  function spawnPack() {
    const p = game.player;
    let x = 0;
    let y = 0;
    for (let tries = 0; tries < 20; tries++) {
      x = rnd(40, game.W - 40);
      y = rnd(40, game.H - 40);
      if (Math.hypot(x - p.x, y - p.y) > 80) break;
    }
    game.packs.push({ x, y, r: 11, ttl: 12, born: game.t });
  }

  function updatePacks(dt) {
    const p = game.player;
    for (let i = game.packs.length - 1; i >= 0; i--) {
      const k = game.packs[i];
      k.ttl -= dt;
      if (k.ttl <= 0) {
        game.packs.splice(i, 1);
        continue;
      }
      if (Math.hypot(k.x - p.x, k.y - p.y) < p.r + k.r + 8) {
        const val = healValueAt(game.t);
        const before = game.hp;
        game.hp = Math.min(HP_MAX, game.hp + val);
        addFloat(p.x, p.y - 26, `+${game.hp - before}`, '#6dff9a');
        burst(k.x, k.y, 12, '#6dff9a');
        Sound.heal();
        game.packs.splice(i, 1);
        updateHud();
      }
    }
  }

  function burst(x, y, n, color) {
    for (let i = 0; i < n; i++) {
      const a = rnd(0, TAU);
      const sp = rnd(40, 240);
      game.particles.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rnd(0.25, 0.7),
        r: rnd(1.2, 3),
        color,
      });
    }
  }

  function addFloat(x, y, text, color) {
    game.floats.push({ x, y, text, color, life: 0.9 });
  }

  function updateEffects(dt) {
    for (let i = game.particles.length - 1; i >= 0; i--) {
      const q = game.particles[i];
      q.life -= dt;
      if (q.life <= 0) {
        game.particles.splice(i, 1);
        continue;
      }
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      q.vx *= 0.92;
      q.vy *= 0.92;
    }
    for (let i = game.floats.length - 1; i >= 0; i--) {
      const f = game.floats[i];
      f.life -= dt;
      f.y -= 26 * dt;
      if (f.life <= 0) game.floats.splice(i, 1);
    }
  }

  /* ================= HUD ================= */
  function updateHud() {
    const pct = clamp(game.hp / HP_MAX, 0, 1);
    els.hpFill.style.width = `${pct * 100}%`;
    els.hpFill.className = 'hp-fill' + (pct <= 0.3 ? ' low' : pct <= 0.6 ? ' mid' : '');
    els.hpText.textContent = String(Math.ceil(game.hp));
    els.timeText.textContent = formatTime(game.t);
    els.killText.textContent = String(game.kills);
    const dmg = damageAt(game.t);
    els.dangerText.textContent = `怪物伤害 ${dmg}`;
    els.dangerText.classList.toggle('high', dmg >= 25);
  }

  /* ================= 渲染 ================= */
  function render(ts) {
    const W = game.W;
    const H = game.H;
    ctx.setTransform(game.dpr, 0, 0, game.dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    const bg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.1, W / 2, H / 2, Math.max(W, H) * 0.75);
    bg.addColorStop(0, '#121a2c');
    bg.addColorStop(1, '#070a12');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    drawStars(ts);

    const sh = game.shake;
    ctx.save();
    if (sh > 0.5) ctx.translate(rnd(-sh, sh), rnd(-sh, sh));

    drawPacks();
    drawMonsters();
    drawBullets();
    drawPlayer(ts);
    ctx.restore();

    drawParticles();
    drawFloats();

    if (game.flash > 0) {
      ctx.fillStyle = `rgba(255, 60, 60, ${game.flash * 0.35})`;
      ctx.fillRect(0, 0, W, H);
    }
  }

  function drawStars(ts) {
    for (const s of game.stars) {
      const alpha = 0.25 + 0.75 * Math.abs(Math.sin(s.tw + ts * 0.001 * s.sp));
      ctx.globalAlpha = alpha;
      ctx.fillStyle = '#bcd7ff';
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawPlayer(ts) {
    const p = game.player;
    const blink = game.iframe > 0 && Math.floor(ts / 70) % 2 === 0;

    ctx.save();
    ctx.globalAlpha = blink ? 0.35 : 1;
    ctx.translate(p.x, p.y);
    ctx.rotate(game.aim);

    ctx.shadowColor = '#58e0ff';
    ctx.shadowBlur = 18;
    ctx.fillStyle = '#d8f6ff';
    ctx.beginPath();
    ctx.moveTo(16, 0);
    ctx.lineTo(-10, 9);
    ctx.lineTo(-5, 0);
    ctx.lineTo(-10, -9);
    ctx.closePath();
    ctx.fill();

    ctx.shadowBlur = 0;
    ctx.fillStyle = '#58e0ff';
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, TAU);
    ctx.fill();
    ctx.restore();

    if (game.iframe > 0) {
      ctx.save();
      ctx.strokeStyle = 'rgba(120, 220, 255, 0.55)';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r + 10, 0, TAU);
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawMonsters() {
    for (const m of game.monsters) {
      const spikes = m.type === 'fast' ? 6 : 8;
      const rot = Math.sin(m.wob) * 0.15;
      const jitter = m.flash > 0 ? 1.15 : 1;
      const base = m.type === 'fast' ? '#ffb347' : m.type === 'big' ? '#c084fc' : '#ff6f91';

      ctx.save();
      ctx.translate(m.x, m.y);
      ctx.rotate(rot);
      ctx.fillStyle = m.flash > 0 ? '#ffffff' : base;
      ctx.shadowColor = base;
      ctx.shadowBlur = 14;
      ctx.beginPath();
      for (let i = 0; i < spikes * 2; i++) {
        const ang = (i / (spikes * 2)) * TAU;
        const rad = (i % 2 === 0 ? m.r * jitter : m.r * 0.62) * (1 + Math.sin(m.wob + i) * 0.05);
        const x = Math.cos(ang) * rad;
        const y = Math.sin(ang) * rad;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      if (m.hp < m.maxHp) {
        const w = Math.max(24, m.r * 2.2);
        const h = 4;
        const x0 = m.x - w / 2;
        const y0 = m.y - m.r - 12;
        ctx.fillStyle = 'rgba(0,0,0,.55)';
        ctx.fillRect(x0, y0, w, h);
        ctx.fillStyle = '#ff7a7a';
        ctx.fillRect(x0, y0, (w * m.hp) / m.maxHp, h);
      }
    }
  }

  function drawBullets() {
    ctx.save();
    ctx.shadowColor = '#7fe7ff';
    ctx.shadowBlur = 10;
    ctx.fillStyle = '#bff3ff';
    for (const b of game.bullets) {
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawPacks() {
    for (const k of game.packs) {
      const pulse = 1 + Math.sin(game.t * 5 + k.born) * 0.1;
      const alpha = k.ttl < 3 ? 0.4 + Math.abs(Math.sin(game.t * 8)) * 0.6 : 1;

      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.shadowColor = '#6dff9a';
      ctx.shadowBlur = 16;
      ctx.fillStyle = '#0f2a1b';
      ctx.beginPath();
      ctx.arc(k.x, k.y, k.r * pulse, 0, TAU);
      ctx.fill();

      ctx.fillStyle = '#6dff9a';
      const s = k.r * 0.85 * pulse;
      const w = k.r * 0.34;
      ctx.fillRect(k.x - s, k.y - w / 2, s * 2, w);
      ctx.fillRect(k.x - w / 2, k.y - s, w, s * 2);
      ctx.restore();
    }
  }

  function drawParticles() {
    for (const q of game.particles) {
      ctx.globalAlpha = clamp(q.life / 0.7, 0, 1);
      ctx.fillStyle = q.color;
      ctx.beginPath();
      ctx.arc(q.x, q.y, q.r, 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawFloats() {
    ctx.save();
    ctx.textAlign = 'center';
    ctx.font = 'bold 15px "PingFang SC", "Microsoft YaHei", sans-serif';
    for (const f of game.floats) {
      ctx.globalAlpha = clamp(f.life / 0.9, 0, 1);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, f.x, f.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  /* ================= 主循环 ================= */
  function frame(ts) {
    requestAnimationFrame(frame);
    if (game.state !== 'playing') {
      render(ts);
      return;
    }
    if (document.hidden) {
      game.last = ts;
      return;
    }
    const dt = game.last ? Math.min(0.05, (ts - game.last) / 1000) : 0.016;
    game.last = ts;
    if (dt > 0) update(dt);
    render(ts);
  }

  /* ================= 输入 ================= */
  function toCanvasPoint(evt) {
    const rect = els.canvas.getBoundingClientRect();
    return {
      x: ((evt.clientX - rect.left) / rect.width) * game.W,
      y: ((evt.clientY - rect.top) / rect.height) * game.H,
    };
  }

  function onPointer(type) {
    return (evt) => {
      if (game.state !== 'playing') return;
      if (evt.pointerType === 'mouse' && type === 'pointerdown' && evt.button !== 0) return;
      const pt = toCanvasPoint(evt);
      game.pointer.x = pt.x;
      game.pointer.y = pt.y;
      game.pointer.active = true;
      if (evt.cancelable) evt.preventDefault();
    };
  }

  els.canvas.addEventListener('pointermove', onPointer('pointermove'));
  els.canvas.addEventListener('pointerdown', onPointer('pointerdown'));

  window.addEventListener('keydown', (evt) => {
    const key = evt.key.toLowerCase();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(key)) {
      if (game.state === 'playing') evt.preventDefault();
    }
    game.keys.add(key);
    game.pointer.active = false;
  });

  window.addEventListener('keyup', (evt) => {
    game.keys.delete(evt.key.toLowerCase());
  });

  window.addEventListener('blur', () => game.keys.clear());

  /* ================= 事件绑定 ================= */
  els.btnStart.addEventListener('click', startGame);
  els.btnAgain.addEventListener('click', startGame);
  els.btnRetry.addEventListener('click', submitResult);
  els.btnLeaderboard.addEventListener('click', openLeaderboard);
  els.btnCloseLeaderboard.addEventListener('click', closeLeaderboard);
  els.btnLogout.addEventListener('click', logout);
  els.btnSound.addEventListener('click', () => {
    const muted = Sound.toggleMute();
    els.btnSound.textContent = muted ? '🔇' : '🔊';
    els.btnSound.title = muted ? '当前静音，点击开启音效' : '音效已开启，点击静音';
  });
  els.tabLogin.addEventListener('click', () => setAuthMode('login'));
  els.tabRegister.addEventListener('click', () => setAuthMode('register'));
  els.btnAuthSubmit.addEventListener('click', submitAuth);
  els.authConfirm.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') submitAuth();
  });
  els.authPassword.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') submitAuth();
  });

  window.addEventListener('resize', resize);

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) game.last = 0;
  });

  /* ================= 初始化 ================= */
  function initSoundButton() {
    const muted = Sound.isMuted();
    els.btnSound.textContent = muted ? '🔇' : '🔊';
    els.btnSound.title = muted ? '当前静音，点击开启音效' : '音效已开启，点击静音';
  }

  initSoundButton();
  resize();
  updateHud();
  initAuth();
  requestAnimationFrame(frame);

  // 暴露给开发者工具 / 自动化测试使用，不影响正常游玩
  window.__BS_GAME = game;
})();
