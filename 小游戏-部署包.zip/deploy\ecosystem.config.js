/**
 * PM2 配置示例。
 * 用法：pm2 start deploy/ecosystem.config.js
 */
const path = require('node:path');

module.exports = {
  apps: [
    {
      name: 'blood-survival',
      script: path.join(__dirname, '../server/index.js'),
      cwd: path.join(__dirname, '..'),
      instances: 1,
      max_memory_restart: '300M',
      time: true,
      env: {
        NODE_ENV: 'production',
        PORT: process.env.PORT || 3000,
        HOST: process.env.HOST || '127.0.0.1',
        TRUST_PROXY: process.env.TRUST_PROXY || '1',
        // 可选：不设置时服务会自动生成并持久化到 server/data/.session-secret
        SESSION_SECRET: process.env.SESSION_SECRET || '',
      },
    },
  ],
};
