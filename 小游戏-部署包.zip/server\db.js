'use strict';

/**
 * SQLite 封装：使用 Node.js 内置的 node:sqlite（需 Node >= 24），零原生依赖。
 *
 * 数据结构（v2，支持账号）：
 *   users(id, username UNIQUE, password_hash, salt, created_at)
 *   scores(id, user_id, survival_seconds, kills, end_hp, created_at)
 *
 * 兼容 v1：旧版 scores 表没有 user_id 列，启动时自动改名为 scores_v1_backup 保留数据。
 */
const fs = require('node:fs');
const path = require('node:path');

let DatabaseSync;
try {
  ({ DatabaseSync } = require('node:sqlite'));
} catch (err) {
  throw new Error('当前 Node 版本不支持 node:sqlite，请升级到 Node 24 及以上：https://nodejs.org/zh-cn/download');
}

const LEGACY_TABLE = 'scores_v1_backup';

function migrate(db) {
  const tables = db
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name IN ('scores','users')")
    .all()
    .map((r) => r.name);
  if (!tables.includes('scores')) return;

  const columns = db.prepare('PRAGMA table_info(scores)').all();
  const hasUserId = columns.some((c) => c.name === 'user_id');
  if (!hasUserId) {
    // v1 旧表：改名为备份表保留数据，新 scores 表会自动创建
    db.exec(`ALTER TABLE scores RENAME TO ${LEGACY_TABLE}`);
  }
}

/**
 * 打开（必要时创建）数据库并初始化表结构。
 * @param {string} file 数据库文件路径，或 ':memory:'
 */
function openDb(file) {
  if (file !== ':memory:') {
    fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  }
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA synchronous = NORMAL');
  migrate(db);
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS scores (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      survival_seconds REAL NOT NULL,
      kills INTEGER NOT NULL,
      end_hp INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_scores_user ON scores (user_id, survival_seconds DESC, kills DESC);
    CREATE INDEX IF NOT EXISTS idx_scores_rank ON scores (survival_seconds DESC, kills DESC, created_at ASC);
  `);
  return db;
}

/**
 * 「每人一条最好成绩」的排名 CTE：
 * 先按用户分组取最好成绩（存活时间优先、击杀次之），再对最好成绩整体排名。
 */
const RANKED_CTE = `
  WITH best AS (
    SELECT s.user_id, s.survival_seconds, s.kills, s.end_hp, s.created_at,
           ROW_NUMBER() OVER (
             PARTITION BY s.user_id
             ORDER BY s.survival_seconds DESC, s.kills DESC, s.id ASC
           ) AS rn
    FROM scores s
  ),
  ranked AS (
    SELECT user_id, survival_seconds, kills, end_hp, created_at,
           ROW_NUMBER() OVER (
             ORDER BY survival_seconds DESC, kills DESC, created_at ASC, user_id ASC
           ) AS pos
    FROM best
    WHERE rn = 1
  )
`;

class GameDb {
  constructor(db) {
    this.db = db;
    this.q = {
      createUser: db.prepare(
        'INSERT INTO users (username, password_hash, salt, created_at) VALUES (?, ?, ?, ?)'
      ),
      userByName: db.prepare('SELECT id, username, password_hash, salt FROM users WHERE username = ?'),
      userById: db.prepare('SELECT id, username FROM users WHERE id = ?'),
      insertScore: db.prepare(
        'INSERT INTO scores (user_id, survival_seconds, kills, end_hp, created_at) VALUES (?, ?, ?, ?, ?)'
      ),
      userBest: db.prepare(`
        SELECT survival_seconds, kills, end_hp, created_at
        FROM scores
        WHERE user_id = ?
        ORDER BY survival_seconds DESC, kills DESC, id ASC
        LIMIT 1
      `),
      userRank: db.prepare(`${RANKED_CTE} SELECT pos FROM ranked WHERE user_id = ?`),
      leaderboard: db.prepare(`${RANKED_CTE}
        SELECT u.username, r.survival_seconds, r.kills, r.end_hp, r.created_at
        FROM ranked r JOIN users u ON u.id = r.user_id
        ORDER BY r.pos
        LIMIT ?
      `),
      rankedCount: db.prepare('SELECT COUNT(*) AS c FROM (SELECT user_id FROM scores GROUP BY user_id)'),
    };
  }

  createUser({ username, passwordHash, salt, createdAt }) {
    const r = this.q.createUser.run(username, passwordHash, salt, createdAt);
    return Number(r.lastInsertRowid);
  }

  findUserByName(username) {
    return this.q.userByName.get(username);
  }

  findUserById(id) {
    return this.q.userById.get(id);
  }

  insertScore({ userId, survivalSeconds, kills, endHp, createdAt }) {
    const r = this.q.insertScore.run(userId, survivalSeconds, kills, endHp, createdAt);
    return Number(r.lastInsertRowid);
  }

  /** 某用户的历史最好成绩；没有成绩返回 null */
  userBest(userId) {
    const row = this.q.userBest.get(userId);
    if (!row) return null;
    return {
      survivalSeconds: row.survival_seconds,
      kills: row.kills,
      endHp: row.end_hp,
      createdAt: row.created_at,
    };
  }

  /** 某用户个人最好成绩在全体用户中的排名（1 起）；没有成绩返回 null */
  userRank(userId) {
    const row = this.q.userRank.get(userId);
    return row ? row.pos : null;
  }

  /** 排行榜：每个用户一条最好成绩 */
  leaderboard(limit) {
    return this.q.leaderboard.all(limit).map((r) => ({
      username: r.username,
      survivalSeconds: r.survival_seconds,
      kills: r.kills,
      endHp: r.end_hp,
      createdAt: r.created_at,
    }));
  }

  /** 有成绩的用户数量（即排行榜总人数） */
  rankedUserCount() {
    return this.q.rankedCount.get().c;
  }

  close() {
    this.db.close();
  }
}

module.exports = { openDb, GameDb };
