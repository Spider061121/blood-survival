'use strict';

const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { openDb, GameDb } = require('./db');
const { createApp } = require('./app');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data', 'game.db');

/**
 * 会话签名密钥：优先读环境变量 SESSION_SECRET；
 * 否则在数据目录生成并持久化一个随机密钥，重启后已登录用户不掉线。
 */
function loadSessionSecret(dataDir) {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  const file = path.join(dataDir, '.session-secret');
  try {
    const existing = fs.readFileSync(file, 'utf8').trim();
    if (existing) return existing;
  } catch (_) {
    /* 不存在则生成 */
  }
  const secret = crypto.randomBytes(32).toString('hex');
  try {
    fs.mkdirSync(dataDir, { recursive: true });
    fs.writeFileSync(file, secret, 'utf8');
  } catch (_) {
    /* 只读目录也能运行，只是重启后会话失效 */
  }
  return secret;
}

const rawDb = openDb(DB_FILE);
const db = new GameDb(rawDb);
const sessionSecret = loadSessionSecret(path.dirname(DB_FILE));
const app = createApp({ db, sessionSecret });

const server = app.listen(PORT, HOST, () => {
  console.log(`[血战到底] 服务已启动: http://${HOST}:${PORT}`);
  console.log(`[血战到底] 数据库文件: ${DB_FILE}`);
  console.log('[血战到底] 账号系统已启用（会话有效期 7 天）');
  console.log('[血战到底] 宝塔部署时在站点里反代到该地址即可。');
});

function shutdown(signal) {
  console.log(`[血战到底] 收到 ${signal}，正在退出...`);
  server.close(() => {
    try {
      db.close();
    } catch (_) {
      /* ignore */
    }
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
